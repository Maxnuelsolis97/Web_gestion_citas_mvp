INSERT INTO medico (usuario_id, especialidad_id, codigo_colegiatura) VALUES
(2, 1, 'CMP-12345'),
(3, 2, 'CMP-67890');
