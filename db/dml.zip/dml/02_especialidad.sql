INSERT INTO especialidad (nombre, descripcion) VALUES
('Medicina General', 'Atención médica general'),
('Pediatría', 'Atención de niños'),
('Ginecología', 'Salud de la mujer'),
('Traumatología', 'Lesiones músculo-esqueléticas'),
('Cardiología', 'Enfermedades del corazón');
